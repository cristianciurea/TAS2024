package ro.ase.tas;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.Map;

import static org.junit.Assert.assertEquals;


public class BmiCalculateBDDSteps {

    WebDriver driver;// = new ChromeDriver();

    @Before
    public void setUp() {
        //driver = new ChromeDriver();
        //System.setProperty("webdriver.http.factory", "jdk-http-client");
        System.setProperty("webdriver.http.factory", "jdk-http-client");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    }

    @After
    public void shutDown() {
        driver.quit();
    }

    @Given("I am on BMI Calculator")
    public void iAmOnBMICalculator() {
        driver.get("http://cristianciurea.ase.ro/ruby/bmicalculator.html");
    }

    @When("I fill in the following:")
    public void iFillInTheFollowing(Map<String, String> input) {
        for (String field : input.keySet()) {
            driver.findElement(By.id(field)).sendKeys(input.get(field));
        }
    }

    @And("I wait for {int} seconds")
    public void iWaitForSeconds(int arg0) throws InterruptedException {

        Thread.sleep(arg0 * 1000L);
    }

    @When("I press {string}")
    public void iPress(String arg0) {
        driver.findElement(By.id(arg0)).click();
    }

    @And("I wait again for {int} seconds")
    public void iWaitAgainForSeconds(int arg0) throws InterruptedException {
        Thread.sleep(arg0 * 1000L);
    }

    @Then("I should see following:")
    public void iShouldSeeFollowing(Map<String, String> result) {

        for (String field : result.keySet()) {

            WebElement text  = driver.findElement(By.id(field));
            String valoareExistenta = text.getAttribute("value");//getText() nu merge
            String valoareAsteptat = result.get(field);
            assertEquals(valoareAsteptat, valoareExistenta);
        }
    }
}
